
from ddtrace.ext import AppTypes

SERVICE = "memcached"
TYPE = AppTypes.cache

QUERY = "memcached.query"
