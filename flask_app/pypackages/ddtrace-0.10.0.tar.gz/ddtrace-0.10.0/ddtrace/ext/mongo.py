
TYPE = 'mongodb'

COLLECTION = 'mongodb.collection'
DB = 'mongodb.db'
ROWS = 'mongodb.rows'
QUERY = 'mongodb.query'

